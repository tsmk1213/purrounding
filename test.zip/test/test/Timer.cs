﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Windows;

namespace test
{
    public class Timer
    {
        private Button TimerButton;

        public static int sec = 0;
        public static bool study = true;
        public static int studyNum = 10;
        public static int restNum = 2;

        public Timer(Button timerButton)
        {
            TimerButton = timerButton;

            TimerButton.Click += InitTimer;
            TimerButton.MouseRightButtonDown += InputNum;
        }

        public void InitTimer(object sender, RoutedEventArgs e)
        {
            // 1초 마다 Tick 됩니다.
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);

            // Event 특성상 여러 이벤트를 등록시킬 수 있습니다.
            //Tick될 때마다 이 이벤트들이 순서대로 호출됨. 
            timer.Tick += Timer_Tick;
            timer.Tick += Timer_Tick2;
            timer.Tick += Timer_Tick3;

            timer.Start();
        }

        private void Timer_Tick(object? sender, System.EventArgs e)
        {
            sec = sec + 1;
        }

        private void Timer_Tick2(object? sender, System.EventArgs e)
        {
            if (study == true && sec == studyNum)
            {
                MessageBox.Show($"{studyNum}초가 지나갔습니다!쉬었다합시다");
                study = false;
                sec = 0;
            }

        }
        private void Timer_Tick3(object? sender, System.EventArgs e)
        {
            if (study == false && sec == restNum)
            {
                MessageBox.Show($"{restNum}초가 지나갔습니다!다시공부합시다");
                study = true;
                sec = 0;
            }

        }

        //아래부터는 우클릭시 가능한 시간값 설정 부분임. 

        public void InputNum(object sender, RoutedEventArgs e) //우클릭시 SetTime 열리게 함
        {
            SetTime newWindow = new SetTime();
            newWindow.DataSubmitted += NewWindow_DataSubmitted;
            newWindow.Show();

        }
        private void NewWindow_DataSubmitted(object? sender, DataEventArgs e) //SetTime에서 받아온 정수값을 Timer에 적용 (아래함수참고)
        {
            studyNum = e.StudyTime;
            restNum = e.RestTime;
        }
    }

    public class DataEventArgs : EventArgs //(SetTime.xaml.cs참고)
    {
        public int StudyTime { get; set; }
        public int RestTime { get; set; }
    }
}
