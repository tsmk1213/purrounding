﻿using pomodoro;
using audio;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Shapes;

namespace purrounding
{
    public partial class MainWindow : Window
    {
        private GifBitmapDecoder? gifDecoder;
        private int frameIndex = 0;
        private DispatcherTimer? frameTimer;
        private DispatcherTimer? moveTimer;
        private Random random = new Random();
        private bool moveRight = true;  // 초기 이동 방향 설정
        private DateTime lastDirectionChangeTime;
        private bool isPaused = false;
        private DispatcherTimer? pauseTimer;

        public MainWindow()
        {
            InitializeComponent();
            var screenWidth = SystemParameters.PrimaryScreenWidth;
            var screenHeight = SystemParameters.PrimaryScreenHeight;

            Rectangle.Width = screenWidth;
            Rectangle.Height = screenHeight;

            LoadGif(@"C:\Users\water\Downloads\purrounding\purrounding\purrounding\Images\reverseCat.gif");
            StartMovingImage();

            /**
             고양이 애니메이션 코드를 베이스로 함.
            즉, App.xaml파일에 설정되어있는 시작창은 고양이 애니메이션임.(MainWindow.xaml이라는 창)

            여기에 다른 창들을 show하는 코드를 추가하여
            동시에 여러 창들이 보이는 방식임.

            Window0 : 뽀모도로 시계
            Window1 : 뽀모도로 설정창 (입력받은 값을 Window0쪽으로 넘겨야해서 다른 Window들과 달리 xaml.cs파일 있음)
            Window2 : 로파이 라디오

            각 기능별로 다른 namespace를 사용합니다. 
            MainWindow (고양이 애니메이션) : purrounding
            Window0 (뽀모도로 시계), Window1 (뽀모도로 설정창) : pomodoro 
            Window2 : (로파이 라디오) : audio
            **/

            Window0 window0 = new Window0(); //뽀모도로
            window0.Show();

            Window2 window2 = new Window2(); //오디오
            window2.Show();

        }
        private void LoadGif(string filePath)
        {
            gifDecoder = new GifBitmapDecoder(new Uri(filePath), BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.Default);
            frameTimer = new DispatcherTimer();
            frameTimer.Interval = TimeSpan.FromMilliseconds(100);  // 프레임 간격 설정
            frameTimer.Tick += FrameTimer_Tick;
            frameTimer.Start();
        }

        private void FrameTimer_Tick(object sender, EventArgs e)
        {
            if (gifDecoder != null)
            {
                AnimatedImage.Source = gifDecoder.Frames[frameIndex];
                frameIndex = (frameIndex + 1) % gifDecoder.Frames.Count;
            }
        }

        private void StartMovingImage()
        {
            moveTimer = new DispatcherTimer();
            moveTimer.Interval = TimeSpan.FromMilliseconds(100);  // 이동 간격 설정 (0.1초마다)
            moveTimer.Tick += MoveTimer_Tick;
            lastDirectionChangeTime = DateTime.Now;
            moveTimer.Start();
        }

        private void MoveTimer_Tick(object sender, EventArgs e)
        {
            // if (isPaused) return;  // 멈춘 상태에서는 이동하지 않음

            double moveDistance = 1;  // 이동 거리 설정 (0.1초마다 1만큼 이동, 즉 1초에 10만큼 이동)
            double newLeft = AnimatedImage.Margin.Left + (moveRight ? moveDistance : -moveDistance);

            // 화면 경계를 넘어가지 않도록 제한
            if (newLeft < 0)
            {
                newLeft = 0;
                ChangeDirection();
            }
            else if (newLeft + AnimatedImage.Width > Rectangle.Width)
            {
                newLeft = Rectangle.Width - AnimatedImage.Width;
                ChangeDirection();
            }

            // 최소 10초가 지난 후에만 방향을 랜덤하게 변경
            if ((DateTime.Now - lastDirectionChangeTime).TotalSeconds >= 10)
            {
                if (random.NextDouble() < 0.1)  // 10% 확률로 최소 10초 동안 멈춤
                {
                    //PauseMovement(10000);  // 10초 동안 멈춤
                    //lastDirectionChangeTime = DateTime.Now;
                }
                else if (random.NextDouble() < 0.1)  // 10% 확률로 방향 변경
                {
                    ChangeDirection();
                }
            }

            // 새로운 위치 설정
            AnimatedImage.Margin = new Thickness(newLeft, AnimatedImage.Margin.Top, 0, 0);
        }

        private void ChangeDirection()
        {
            moveRight = !moveRight;
            lastDirectionChangeTime = DateTime.Now;
            PauseMovement(1000);  // 방향이 바뀔 때 1초 동안 멈춤

            // GIF 방향 뒤집기
            var scaleTransform = new ScaleTransform
            {
                ScaleX = moveRight ? 1 : -1,
                ScaleY = 1
            };
            AnimatedImage.RenderTransformOrigin = new Point(0.5, 0.5);  // 중심을 기준으로 뒤집기
            AnimatedImage.RenderTransform = scaleTransform;
        }

        private void PauseMovement(int milliseconds)
        {
            isPaused = true;
            pauseTimer = new DispatcherTimer();
            pauseTimer.Interval = TimeSpan.FromMilliseconds(milliseconds);
            pauseTimer.Tick += (s, e) =>
            {
                isPaused = false;
                pauseTimer.Stop();
            };
            pauseTimer.Start();
        }
    }
}
/////////////////여기부터 뽀모도로 구현///////////////////
namespace pomodoro
{
    public partial class Window0 : Window
    {

        public Window0()
        {
            InitializeComponent();

        }
        public static int sec = 0;
        public static bool study = true;
        public static int studyNum = 10;
        public static int restNum = 2;

        public void InitTimer(object sender, RoutedEventArgs e)
        {

            // 1초 마다 Tick 됩니다.
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);

            // Event 특성상 여러 이벤트를 등록시킬 수 있습니다.
            //Tick될 때마다 이 이벤트들이 순서대로 호출됨. 
            timer.Tick += Timer_Tick;
            timer.Tick += Timer_Tick2;
            timer.Tick += Timer_Tick3;

            timer.Start();
        }
        private void Timer_Tick(object sender, System.EventArgs e) 
        {
            sec = sec + 1;
        }

        private void Timer_Tick2(object sender, System.EventArgs e) 
        {
            if (study == true && sec == studyNum)
            {
                MessageBox.Show($"{studyNum}초가 지나갔습니다!쉬었다합시다");
                study = false;
                sec = 0;
            }

        }
        private void Timer_Tick3(object sender, System.EventArgs e) 
        {
            if (study == false && sec == restNum)
            {
                MessageBox.Show($"{restNum}초가 지나갔습니다!다시공부합시다");
                study = true;
                sec = 0;
            }

        }
        //namespace pomodoro중 여기까지가 기본적인 타이머 구현
        //아래부터는 우클릭시 가능한 시간값 설정 부분임. 

        public void InputNum(object sender, RoutedEventArgs e) //우클릭시 Window1열리게 함
        {
            Window1 newWindow = new Window1();
            newWindow.DataSubmitted += NewWindow_DataSubmitted;
            newWindow.Show();

        }
        private void NewWindow_DataSubmitted(object sender, DataEventArgs e) //Window1에서 받아온 정수값을 Window0에 적용 (아래함수참고)
        {
            studyNum = e.StudyTime;
            restNum = e.RestTime;
        }

    }
    public class DataEventArgs : EventArgs //(Window1.xaml.cs참고)
    {
        public int StudyTime { get; set; }
        public int RestTime { get; set; }
    }

}
/////////////////여기부터 오디오 구현///////////////////
namespace audio
{

    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        private void MediaMain_MediaEnded(object sender, RoutedEventArgs e)
        {
            mediaMain.Stop();
        }
        private void MediaMain_MediaFailed(object sender, ExceptionRoutedEventArgs e)
        {
            MessageBox.Show("동영상 재생 실패 : " + e.ErrorException.Message.ToString());
        }

        private void file1_Click(object sender, RoutedEventArgs e)
        {
            PlayAudio("C:\\Users\\kshn0\\Desktop\\audio button\\audio button\\mp3_file\\amalgam-217007.mp3");
        }
        private void file2_Click(object sender, RoutedEventArgs e)
        {
            PlayAudio("C:\\Users\\kshn0\\Desktop\\audio button\\audio button\\mp3_file\\amalgam-217007.mp3");
        }
        private void file3_Click(object sender, RoutedEventArgs e)
        {
            PlayAudio("C:\\Users\\kshn0\\Desktop\\audio button\\audio button\\mp3_file\\amalgam-217007.mp3");
        }
        private void file4_Click(object sender, RoutedEventArgs e)
        {
            PlayAudio("C:\\Users\\kshn0\\Desktop\\audio button\\audio button\\mp3_file\\amalgam-217007.mp3");
        }
        private void file5_Click(object sender, RoutedEventArgs e)
        {
            PlayAudio("C:\\Users\\kshn0\\Desktop\\audio button\\audio button\\mp3_file\\amalgam-217007.mp3");
        }

        private void PlayAudio(string fileName)
        {
            mediaMain.Source = new Uri(fileName, UriKind.Absolute);
            mediaMain.Play();
        }

        private void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            if (mediaMain.Source == null)
            {
                return;
            }

            mediaMain.Play();
        }

        private void BtnStop_Click(object sender, RoutedEventArgs e)
        {
            if (mediaMain.Source == null)
            {
                return;
            }

            mediaMain.Stop();
        }

        private void BtnPause_Click(object sender, RoutedEventArgs e)
        {
            if (mediaMain.Source == null)
            {
                return;
            }

            mediaMain.Pause();
        }
    }
}