﻿using System.Numerics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;


namespace toy_due22
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            SetWindow();
            ProgramStarted();
        }
        private void SetWindow() {
            var screenWidth = SystemParameters.PrimaryScreenWidth;
            var screenHeight = SystemParameters.PrimaryScreenHeight;
            this.Width = screenWidth;
            this.Height = screenHeight;
            this.Left = 0;
            this.Top = 0;
            this.WindowStyle = WindowStyle.None;
            this.AllowsTransparency = true;
            this.Background = Brushes.Transparent;
        }

        private void ProgramStarted()
        {
            DispatcherTimer mainTimer = new DispatcherTimer();
            mainTimer.Interval = TimeSpan.FromMilliseconds(100); 
            mainTimer.Tick += MainTimer_Tick;
            mainTimer.Start();

            InitializeToys();
        }

        //프로그램 실행중 매순간 체크할 사항 (MainTimer_Tick은 상시대기 중인 이벤트니까)
        public void MainTimer_Tick(object sender, EventArgs e)
        {


        }
        private void InitializeToys()
        {
            Toy[] toys = new Toy[2];
            toys[0] = new FishingRod("/Assets/Graphics/Toys/fishingRod.png", this);
            toys[1] = new Yarn("/Assets/Graphics/Toys/yarn.png", this);
        
        }

        class Position 
        {
            protected System.Windows.Point position = new System.Windows.Point(500,1200);
        }
        class Physic : Position
        {
            public const double gravity = -9.8;
            void DragFunc(object sender, MouseEventArgs e)
            {
              

            }
            
            Vector2 GravityF(Vector2 p)
            {

                return p;
            }


        }

        class Toy : Physic
        {
            MainWindow MainWindow;

            public Toy(string filePath, MainWindow MainWindow)
            {
                LoadToyImage(filePath,MainWindow);
            }
            bool onOff = true;//해당 장난감이 커스터마이징 창에서 켜져 있는지 여부
            private void ToyOn(object sender, EventArgs e)
            {
                //해당 장난감을 가지고 놀고 있을때
            }

            public void LoadToyImage(string filePath, MainWindow MainWindow) 
            {

                    // BitmapImage 객체를 통해 이미지 로드

                    // Image 객체 생성
                Image image = new Image();
                image.Width = 30;  // 이미지의 너비 설정
                image.Height = 30; // 이미지의 높이 설정

                // BitmapImage 객체를 통해 이미지 로드
                image.Source = new BitmapImage(new Uri(filePath, UriKind.Relative));

                // Canvas 안에서 이미지 위치 설정
                Canvas.SetTop(image, position.X);
                Canvas.SetLeft(image, position.Y);

                // Canvas에 Image 추가
                MainWindow.myCanvas.Children.Add(image);

                bool _isDragging = false;

                image.AllowDrop = true;
                image.MouseMove += DraggableImage_MouseMove;
                image.MouseDown += DraggableImage_MouseDown;
                image.MouseUp += DraggableImage_MouseUp;
                image.Drop += DraggableImage_Drop;

            void DraggableImage_MouseDown(object sender, MouseButtonEventArgs e)
            {
                Image ?draggedImage = sender as Image;

                if (draggedImage != null)
                {
                    _isDragging = true;
                    draggedImage.CaptureMouse();
                }
            }
            void DraggableImage_MouseMove(object sender, MouseEventArgs e)
            {
                Image ?draggedImage = sender as Image;

                if (_isDragging && draggedImage != null)
                {
                    System.Windows.Point mousePos = e.GetPosition(MainWindow); 
                    Canvas.SetLeft(draggedImage, mousePos.X - draggedImage.ActualWidth / 2);
                    Canvas.SetTop(draggedImage, mousePos.Y - draggedImage.ActualHeight / 2);
                }
            }
            void DraggableImage_MouseUp(object sender, MouseButtonEventArgs e)
            {
                Image ?draggedImage = sender as Image;

                if (draggedImage != null && _isDragging)
                {
                    _isDragging = false;
                    draggedImage.ReleaseMouseCapture();
                }
            }
            void DraggableImage_Drop(object sender, DragEventArgs e)
            {

            }

            }

        }

        class Yarn : Toy
        {

            public Yarn(string filePath, MainWindow MainWindow): base(filePath, MainWindow) // Call the base class constructor
            {
            }
        };

        class FishingRod : Toy
        {
            public FishingRod(string filePath, MainWindow MainWindow) : base(filePath, MainWindow) // Call the base class constructor
            {
            }
        };

    }
}

