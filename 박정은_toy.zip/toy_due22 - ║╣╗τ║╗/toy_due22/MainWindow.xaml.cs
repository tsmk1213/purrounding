﻿using System.Drawing;
using System.Numerics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.TextFormatting;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace toy_due22
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ProgramStarted();

        }
        private void ProgramStarted()
        {
            DispatcherTimer mainTimer = new DispatcherTimer();
            mainTimer.Interval = TimeSpan.FromMilliseconds(100);  // 이동 간격 설정 (0.1초마다)
            mainTimer.Tick += MainTimer_Tick;
            mainTimer.Start();
            InitializeToys();
        }

        //프로그램 실행중 매순간 체크할 사항 (MainTimer_Tick은 상시대기 중인 이벤트니까)
        public void MainTimer_Tick(object sender, EventArgs e)
        {
        }
        private void InitializeToys()
        {
            Toy[] toys = new Toy[2];
            toys[0] = new Yarn("yarnFilePath", this);
            toys[1] = new FishingRod("fishingRodFilePath", this);
        }

        class Position
        {
            protected System.Windows.Point position = new System.Windows.Point(10000, 20000);
        }
        class Physic : Position
        {
            /*기본 물리에 포함되어야 하는 사항
             * 1. 기본 kinematics
             * 2. 
             */ 

            public const double gravity = -9.8;
            void DragFunc(object sender, MouseEventArgs e)
            {
                position = e.GetPosition(null);

                // Rectangle의 중앙이 마우스를 따라가도록 위치 조정
                //Canvas.SetLeft(myRectangle, position.X - myRectangle.Width / 2);
                //Canvas.SetTop(myRectangle, position.Y - myRectangle.Height / 2);

            }
            
            Vector2 GravityF(Vector2 p)
            {

                //toy, furniture를 사용자가 클릭/드래그/ON 하고 있는 상황에서만 
                //매프레임 돌아가면 됨
                //->이라는 구조를 어떻게 하지?
                //-> Toy클래스의 ToyOn이벤트에다가 
                // p = (-9.8 / 2 * Time.deltaTime); 


                return p;
            }

            struct AABB
            {
                public System.Windows.Point min;
                public System.Windows.Point max;
            };
            bool Collision(AABB a, AABB b) 
            {
                if (a.max.X < b.min.X || a.min.X > b.max.X) return false;
                if (a.max.Y < b.min.Y || a.min.Y > b.max.Y) return false;
                return true;
            }

        }

        class Toy : Physic
        {
            MainWindow MainWindow;

            public Toy(string filePath, MainWindow MainWindow)
            {
                LoadToyImage(filePath,MainWindow);

            }
            bool onOff;//해당 장난감이 커스터마이징 창에서 켜져 있는지 여부
            private void ToyOn(object sender, EventArgs e)
            {
                //해당 장난감을 가지고 놀고 있을때
            }

            public void LoadToyImage(string filePath, MainWindow MainWindow) 
            {
                System.Windows.Shapes.Rectangle rect = new System.Windows.Shapes.Rectangle
                {
                    Width = 200,
                    Height = 100,
                    Fill = Brushes.LightBlue,
                };

                Canvas.SetTop(MainWindow.myCanvas, position.X);
                Canvas.SetLeft(MainWindow.myCanvas, position.Y);

                // Add Rectangle to the Grid
                MainWindow.myCanvas.Children.Add(rect);

            }
        }

        //ball클래스는 toy클래스를 상속 받는다. 
        //ball클래스에는 toy클래스에는 없는 roll이라는 물리가 있다.
        //그렇다면 ball에서 물리부분을 오버라이드해서 물려받은 toy의 물리를 살짝 고쳐쓰면된다. 



        class Yarn : Toy
        {
            public Yarn(string filePath, MainWindow MainWindow): base(filePath, MainWindow) // Call the base class constructor
            {
            //@@@@@@@@@@@@@@@@@@@@@@@@@@@디버깅용@@@@@@@@@@@@@@@@@@@@@@@@
            TextBlock myTextBlock = new TextBlock();
            myTextBlock.Text = "@@@@@@@@@털실생성됨@@@@@@";
            myTextBlock.FontSize = 24;
            myTextBlock.HorizontalAlignment = HorizontalAlignment.Center;
            myTextBlock.VerticalAlignment = VerticalAlignment.Center;
            MainWindow.myCanvas.Children.Add(myTextBlock);
            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            }
        };

        class FishingRod : Toy
        {
            public FishingRod(string filePath, MainWindow MainWindow) : base(filePath, MainWindow) // Call the base class constructor
            {
                //@@@@@@@@@@@@@@@@@@@@@@@@@@@디버깅용@@@@@@@@@@@@@@@@@@@@@@@@
                TextBlock myTextBlock = new TextBlock();
                myTextBlock.Text = "@@@@@@@@@낚시대생성됨@@@@@@";
                myTextBlock.FontSize = 24;
                myTextBlock.HorizontalAlignment = HorizontalAlignment.Center;
                myTextBlock.VerticalAlignment = VerticalAlignment.Center;
                MainWindow.myCanvas.Children.Add(myTextBlock);
                //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            }
        };

    }
}
