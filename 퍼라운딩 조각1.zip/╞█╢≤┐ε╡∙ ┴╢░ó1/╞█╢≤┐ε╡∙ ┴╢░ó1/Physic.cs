﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

public class Physic : Position
{
    private DispatcherTimer timer;

    public Physic()
    {
        timer = new DispatcherTimer();
        timer.Interval = TimeSpan.FromMilliseconds(16); // 일단 60으로..
        timer.Tick += OnTimerTick;
    }

    public void Start()
    {
        timer.Start();
    }
    public void Stop()
    {
        timer.Stop();
    }

    private void OnTimerTick(object sender, EventArgs e)
    {
        UpdatePhysics();
        CheckCollision();
    }

    // 물리
    private void UpdatePhysics()
    {
        // 일단 구조만..
    }

    // 충돌 체크
    public void CheckCollision()
    {
        // 일단 구조만22..
    }
}