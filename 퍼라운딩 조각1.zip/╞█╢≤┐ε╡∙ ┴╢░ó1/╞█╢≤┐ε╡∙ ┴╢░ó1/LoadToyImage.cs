﻿public class LoadToyImage
{
    private Toy _fishingRodToy;
    private Toy _yarnToy;

    public LoadToyImage()
    {
        // 이미지 경로
        _fishingRodToy = new Toy(@"C:\Users\water\OneDrive\바탕 화면\퍼라운딩 조각1\퍼라운딩 조각1\낚시대.png");
        _yarnToy = new Toy(@"C:\Users\water\OneDrive\바탕 화면\퍼라운딩 조각1\퍼라운딩 조각1\털실.png");
    }

    public FishingRod GetFishingRod()
    {
        return _fishingRodToy.FishingRod;
    }

    public Yarn GetYarn()
    {
        return _yarnToy.Yarn;
    }
}
