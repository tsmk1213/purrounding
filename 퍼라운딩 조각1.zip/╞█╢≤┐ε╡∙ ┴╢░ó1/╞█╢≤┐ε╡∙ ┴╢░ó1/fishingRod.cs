﻿using System.Windows.Media.Imaging;

public class FishingRod : IToyStrategy
{
    private readonly string _filePath;
    public BitmapImage Image { get; private set; }

    public FishingRod(string filePath)
    {
        _filePath = filePath;
    }

    public void LoadPNG_FR()
    {
        var bitmapImage = new BitmapImage();
        bitmapImage.BeginInit();
        bitmapImage.UriSource = new Uri(_filePath);
        bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
        bitmapImage.EndInit();

        Image = bitmapImage;
    }

    public void Play()
    {
        // Play 메소드 구현
        Console.WriteLine("FishingRod is playing.");
    }
}
