﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GifTest
{
    public interface IPlayAnimationStrategy
    {
        string GifFilePath { get; }
        int speed { get; }
    }


    public class YarnAnimation : IPlayAnimationStrategy
    {
        public string GifFilePath => @"C:\Users\kshn0\Desktop\GifTest\GifTest\image\dd.gif";
        public int speed => 1;

        public YarnAnimation() { }
    }

    public class FishingRodAnimation : IPlayAnimationStrategy
    {
        public string GifFilePath => @"C:\Users\kshn0\Desktop\GifTest\GifTest\image\gg.gif";
        public int speed => 1;

        public FishingRodAnimation() { }
    }
}
