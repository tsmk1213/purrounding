﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace GifTest
{
    public interface IAnimationStrategy
    {
        string GifFilePath { get; }
        int speed { get; }
    }


    public class Walk : IAnimationStrategy
    {
        public string GifFilePath => @"C:\Users\kshn0\Desktop\GifTest\GifTest\image\cat_walk.gif";
        public int speed => 1;

        public Walk() { }
    }

    public class Grooming : IAnimationStrategy
    {
        public string GifFilePath => @"C:\Users\kshn0\Desktop\GifTest\GifTest\image\reverseCat.gif";
        public int speed => 0;

        public Grooming() { }
    }
}
