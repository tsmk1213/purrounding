﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace GifTest
{
    public class PlayAnimation
    {
        private GifBitmapDecoder? gifDecoder;
        private DispatcherTimer? frameTimer;
        private int frameIndex = 0;
        private bool moveLeft = true;

        private Image animatedImage;

        private List<IPlayAnimationStrategy> animations = new List<IPlayAnimationStrategy>();

        public PlayAnimation(Image image, int animationIndex)
        {
            animatedImage = image;

            PlayAnimationManager();

            CenterImage();

            // 전달받은 인덱스를 사용하여 GIF 파일 로드
            if (animationIndex >= 0 && animationIndex < animations.Count)
            {
                LoadGif(animations[animationIndex].GifFilePath);
            }
            else
            {
                throw new ArgumentOutOfRangeException(nameof(animationIndex), "Invalid animation index.");
            }
        }

        // 애니메이션 리스트 생성
        public void PlayAnimationManager()
        {
            animations.Add(new YarnAnimation());
            animations.Add(new FishingRodAnimation());
            // 나머지 애니메이션 추가
        }

        // 프레임 타이머 시작
        private void StartFrameTimer()
        {
            frameTimer = new DispatcherTimer();
            frameTimer.Interval = TimeSpan.FromMilliseconds(100); // 프레임 간격 설정
            frameTimer.Tick += FrameTimer_Tick;
            frameTimer.Start();
        }

        // 기존 타이머 정지
        private void StopFrameTimer()
        {
            if (frameTimer != null && frameTimer.IsEnabled)
            {
                frameTimer.Stop();
            }
        }

        // gif 파일 로드
        public void LoadGif(string filepath)
        {
            // 기존 GIF 해제
            gifDecoder = null;
            frameIndex = 0; // 프레임 인덱스 리셋

            gifDecoder = new GifBitmapDecoder(new Uri(filepath), BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.Default);

            StopFrameTimer(); // 타이머 정지
            StartFrameTimer(); // 새로운 타이머 시작
        }

        // gif 애니메이션의 프레임 업데이트
        private void FrameTimer_Tick(object? sender, EventArgs e)
        {
            if (gifDecoder != null)
            {
                animatedImage.Source = gifDecoder.Frames[frameIndex];
                frameIndex = (frameIndex + 1) % gifDecoder.Frames.Count;
            }
        }

        // 이미지를 중앙에 배치
        private void CenterImage()
        {
            double canvasWidth = 800;
            double canvasHeight = 450;

            // 중앙 위치 계산
            double left = (canvasWidth - animatedImage.Width) / 2;
            double top = (canvasHeight - animatedImage.Height) / 2;

            // 이미지 위치 설정
            Canvas.SetLeft(animatedImage, left);
            Canvas.SetTop(animatedImage, top);
        }

        // 방향 전환 및 이미지 좌우 반전
        private void ChangeDirection(bool isLeftBoundary)
        {
            moveLeft = !moveLeft; // 방향 전환

            // GIF 방향 뒤집기
            var scaleTransform = new ScaleTransform
            {
                ScaleX = moveLeft ? -1 : 1,
                ScaleY = 1
            };

            animatedImage.RenderTransformOrigin = new Point(0.5, 0.5); // 중심을 기준으로 뒤집기
            animatedImage.RenderTransform = scaleTransform;

            // 경계에 도달했을 때 반전
            if (isLeftBoundary)
            {
                scaleTransform.ScaleX = -1; // 왼쪽 경계에 도달
            }
            else
            {
                scaleTransform.ScaleX = 1; // 오른쪽 경계에 도달
            }
        }
    }
}
