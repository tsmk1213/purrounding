﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace GifTest
{
    public class Cat
    {
        // main에서 image 가져오기
        private Image animatedImage;
        // Toy클래스 활성화시 true로 변환하기
        public bool play = false;
        // 몇번째 장난감을 활성화 시켰는지
        public int animationIndex = 0;

        private PlayAnimation? playAnimation;
        private NormalAnimation? normalAnimation;

        public Cat(Image image)
        {
            animatedImage = image;
            play = true;
            animationIndex = 1;

            if (play)
            {
                playAnimation = new PlayAnimation(animatedImage, animationIndex); // AnimatedImage를 전달
            }
            else
            {
                normalAnimation = new NormalAnimation(animatedImage);
            }
        }
    }
}
