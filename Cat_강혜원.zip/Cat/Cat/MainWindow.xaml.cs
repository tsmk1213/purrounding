﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Cat
{
    public partial class MainWindow : Window
    {
        private NormalAnimation normalAnimation;

        public MainWindow()
        {
            InitializeComponent();
            normalAnimation = new NormalAnimation(AnimatedImage); // AnimatedImage를 전달
        }
    }
}
