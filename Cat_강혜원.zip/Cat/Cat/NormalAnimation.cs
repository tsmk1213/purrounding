﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Cat
{
    public class NormalAnimation
    {
        private GifBitmapDecoder? gifDecoder;
        private DispatcherTimer? frameTimer;
        private int frameIndex = 0;
        private DispatcherTimer? moveTimer;
        private bool moveLeft = true;
        private DateTime lastChangeTime; // 마지막 애니메이션/방향 변경 시간
        private Random random = new Random();

        private Image animatedImage;

        private List<IAnimationStrategy> animations = new List<IAnimationStrategy>();
        private double[] animationProbabilities = Array.Empty<double>(); // 기본값으로 빈 배열로 초기화

        private IAnimationStrategy? selectedAnimation;

        public NormalAnimation(Image image)
        {
            animatedImage = image;

            AnimationManager();

            PlayRandomAnimation();
            CenterImage();

            StartMovingImage();
        }

        // 애니메이션 리스트 생성
        public void AnimationManager()
        {
            animations.Add(new Walk());
            animations.Add(new Grooming());
            // 나머지 애니메이션 추가
        }

        // 랜덤 애니메이션 재생
        public void PlayRandomAnimation()
        {
            lastChangeTime = DateTime.Now;

            int index = random.Next(animations.Count);
            selectedAnimation = animations[index];

            if (selectedAnimation != null)
            {
                StopFrameTimer();

                // 선택된 애니메이션의 GIF 파일 경로로 LoadGif 호출
                LoadGif(selectedAnimation.GifFilePath);
            }
        }

        // 프레임 타이머 시작
        private void StartFrameTimer()
        {
            frameTimer = new DispatcherTimer();
            frameTimer.Interval = TimeSpan.FromMilliseconds(100); // 프레임 간격 설정
            frameTimer.Tick += FrameTimer_Tick;
            frameTimer.Start();
        }

        // 기존 타이머 정지
        private void StopFrameTimer()
        {
            if (frameTimer != null && frameTimer.IsEnabled)
            {
                frameTimer.Stop();
            }
        }

        // gif 파일 로드
        public void LoadGif(string filepath)
        {
            // 기존 GIF 해제
            gifDecoder = null;
            frameIndex = 0; // 프레임 인덱스 리셋

            gifDecoder = new GifBitmapDecoder(new Uri(filepath), BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.Default);

            StopFrameTimer(); // 타이머 정지
            StartFrameTimer(); // 새로운 타이머 시작
        }

        // gif 애니메이션의 프레임 업데이트
        private void FrameTimer_Tick(object? sender, EventArgs e)
        {
            if (gifDecoder != null)
            {
                animatedImage.Source = gifDecoder.Frames[frameIndex];
                frameIndex = (frameIndex + 1) % gifDecoder.Frames.Count;
            }
        }

        // 이미지를 중앙에 배치
        private void CenterImage()
        {
            double canvasWidth = 800;
            double canvasHeight = 450;

            // 중앙 위치 계산
            double left = (canvasWidth - animatedImage.Width) / 2;
            double top = (canvasHeight - animatedImage.Height) / 2;

            // 이미지 위치 설정
            Canvas.SetLeft(animatedImage, left);
            Canvas.SetTop(animatedImage, top);
        }

        // 이미지 이동 시작
        private void StartMovingImage()
        {
            // 기존의 moveeTimer가 존재하면 정지
            if (moveTimer != null && moveTimer.IsEnabled)
            {
                moveTimer.Stop();
            }

            moveTimer = new DispatcherTimer();
            moveTimer.Interval = TimeSpan.FromMilliseconds(100);  // 이동 간격 설정 (0.1초마다)
            moveTimer.Tick += MoveTimer_Tick;
            lastChangeTime = DateTime.Now;
            moveTimer.Start();
        }

        // 이미지 위치 이동
        private void MoveTimer_Tick(object? sender, EventArgs e)
        {
            double moveDistance = 1;  // 이동 거리 설정
            int speed = selectedAnimation?.speed ?? 1; // 이동 속도 설정 (기본값 1)
            double currentLeft = Canvas.GetLeft(animatedImage);
            double newLeft = currentLeft + (moveLeft ? -moveDistance : moveDistance) * speed;

            double canvasWidth = 800;

            // 캔버스 너비를 넘어가지 않도록 제한
            if (newLeft < 0)
            {
                newLeft = 0;
                ChangeDirection(true);
            }
            else if (newLeft + animatedImage.Width > canvasWidth)
            {
                newLeft = canvasWidth - animatedImage.Width;
                ChangeDirection(false);
            }

            // 최소 15초가 지난 후에만 애니메이션/방향을 랜덤하게 변경
            if ((DateTime.Now - lastChangeTime).TotalSeconds >= 15)
            {
                if (random.NextDouble() < 0.1)  // 10% 확률로 애니메이션 변경
                {
                    PlayRandomAnimation(); 
                }
                else if (random.NextDouble() < 0.1)  // 10% 확률로 방향 변경
                {
                    ChangeDirection(moveLeft ? true : false);
                }
            }

            // 새로운 위치 설정
            Canvas.SetLeft(animatedImage, newLeft);
        }

        // 방향 전환 및 이미지 좌우 반전
        private void ChangeDirection(bool isLeftBoundary)
        {
            moveLeft = !moveLeft; // 방향 전환
            lastChangeTime = DateTime.Now;

            // GIF 방향 뒤집기
            var scaleTransform = new ScaleTransform
            {
                ScaleX = moveLeft ? -1 : 1,
                ScaleY = 1
            };

            animatedImage.RenderTransformOrigin = new Point(0.5, 0.5); // 중심을 기준으로 뒤집기
            animatedImage.RenderTransform = scaleTransform;

            // 경계에 도달했을 때 반전
            if (isLeftBoundary)
            {
                scaleTransform.ScaleX = -1; // 왼쪽 경계에 도달
            }
            else
            {
                scaleTransform.ScaleX = 1; // 오른쪽 경계에 도달
            }
        }
    }
}
