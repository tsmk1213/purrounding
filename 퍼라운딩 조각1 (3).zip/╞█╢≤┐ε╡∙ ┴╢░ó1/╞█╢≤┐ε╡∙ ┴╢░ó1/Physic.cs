﻿using System.Windows.Controls;
using System.Windows.Threading;
using System.Windows;

public class Physic : Position
{
    private DispatcherTimer timer;

    public List<Image> toyImages;
    private double gravity = 0.5; // 중력 값
    private double[] velocitiesY; // Y축 속도

    // 가구 오브젝트 충돌 관련은 여기에 추가
    private Image catImage;
    private Button toyBoxButton;

    public Physic(Image cat, List<Image> toys, Button toyBox)
    {
        catImage = cat;
        toyImages = toys;
        toyBoxButton = toyBox;
        velocitiesY = new double[toyImages.Count];

        timer = new DispatcherTimer();
        timer.Interval = TimeSpan.FromMilliseconds(16);
        timer.Tick += OnTimerTick;
    }

    public void Start()
    {
        timer.Start();
    }

    public void Stop()
    {
        timer.Stop();
    }

    private void OnTimerTick(object? sender, EventArgs e)
    {
        UpdatePhysics();
        CheckCollision();
    }

    private void UpdatePhysics()
    {
        for (int i = 0; i < toyImages.Count; i++)
        {
            velocitiesY[i] += gravity;
            double newY = Canvas.GetTop(toyImages[i]) + velocitiesY[i];

            double floorY = Application.Current.MainWindow.Height - toyImages[i].ActualHeight;

            if (newY > floorY)
            {
                newY = floorY;
                velocitiesY[i] = 0;
            }

            // 장난감 박스 버튼과 같은 Y좌표로 설정했음!!
            double toyBoxY = Canvas.GetTop(toyBoxButton);
            Canvas.SetTop(toyImages[i], toyBoxY);
        }
    }

    private void CheckCollision()
    {
        var catRectangle = new Rectangle(new Point(Canvas.GetLeft(catImage), Canvas.GetTop(catImage)),
                                          catImage.ActualWidth, catImage.ActualHeight);

        // 가구 오브젝트 이 형식으로 추가하면 됨 (나중에는 리스트 형식으로 정리해서 묶어놓는게 나을 것 같긴 한데.. 일단은 이렇게 해놨습니다~~)
        var toyBoxRectangle = new Rectangle(new Point(Canvas.GetLeft(toyBoxButton), Canvas.GetTop(toyBoxButton)),
                                            toyBoxButton.ActualWidth, toyBoxButton.ActualHeight);

        if (catRectangle.Intersects(toyBoxRectangle))   // 일단은 지금 고양이랑 장난감 박스만 충돌하는 건데.. 나중에는 list 사용해서 바꿔야 하고. 근데 장난감 박스랑 고양이 충돌이 의미가 있나..? 싶은?
        {
            MessageBox.Show("cat과 장난감 상자가 충돌했습니다!");
        }
    }

    public class Rectangle
    {
        public Point Position { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }

        public Rectangle(Point position, double width, double height)
        {
            Position = position;
            Width = width;
            Height = height;
        }

        public bool Intersects(Rectangle other)
        {
            return Position.X < other.Position.X + other.Width &&
                   Position.X + Width > other.Position.X &&
                   Position.Y < other.Position.Y + other.Height &&
                   Position.Y + Height > other.Position.Y;
        }
    }
}
