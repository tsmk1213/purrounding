﻿using System.Windows.Media.Imaging;

public class Yarn : IToyStrategy
{
    private readonly string _filePath;
    public BitmapImage? Image { get; private set; }

    public Yarn(string filePath)
    {
        _filePath = filePath;
    }

    public void LoadPNG_Y()
    {
        var bitmapImage = new BitmapImage();
        bitmapImage.BeginInit();
        bitmapImage.UriSource = new Uri(_filePath);
        bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
        bitmapImage.EndInit();

        Image = bitmapImage;
    }

    public void Play()
    {
        Console.WriteLine("Yarn is playing.");
    }

    public void BouncePhysic()
    {

    }
}
