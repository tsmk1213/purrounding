﻿using System;
using System.Windows.Media.Imaging;


public interface IToyStrategy
{
    void Play();
}

public class Toy
{
    // private Position position;
    private bool onoff;
    private IToyStrategy[] toys;

    public FishingRod FishingRod { get; private set; } // FishingRod 속성
    public Yarn Yarn { get; private set; } // Yarn 속성

    public Toy(string filePath)
    {
        FishingRod = new FishingRod(filePath);
        Yarn = new Yarn(filePath);

        toys = new IToyStrategy[2];
        toys[0] = FishingRod; // toys 배열에 FishingRod 추가
        toys[1] = Yarn; // toys 배열에 Yarn 추가
    }

    public void LoadImage()
    {
        FishingRod?.LoadPNG_FR(); // null 체크 후 호출
        Yarn?.LoadPNG_Y();
    }

    protected void ToyOn(bool on)
    {
        onoff = on;
    }
    protected void ToyOff(bool off)
    {
        onoff = !off;
    }

    public void Move(int deltaX, int deltaY)
    {

    }
}
public class LoadToyImage
{
    private Toy _fishingRodToy;
    private Toy _yarnToy;

    public LoadToyImage()
    {
        // 이미지 경로
        _fishingRodToy = new Toy(@"C:\Users\water\OneDrive\바탕 화면\퍼라운딩 조각1\퍼라운딩 조각1\낚시대.png");
        _yarnToy = new Toy(@"C:\Users\water\OneDrive\바탕 화면\퍼라운딩 조각1\퍼라운딩 조각1\털실.png");
    }

    public FishingRod GetFishingRod()
    {
        return _fishingRodToy.FishingRod;
    }

    public Yarn GetYarn()
    {
        return _yarnToy.Yarn;
    }
}
