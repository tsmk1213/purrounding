﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Controls;  // 밑에 마우스 드래그 할 때 Image 사용하기 위해서 필요함
using System.Diagnostics;

namespace 퍼라운딩_조각1
{
    public partial class MainWindow : Window
    {
        private LoadToyImage _loadToyImage;
        private Physic physic;

        private bool Toyonoff;
        private bool _isDragging = false;

        public MainWindow()
        {
            InitializeComponent();
            _loadToyImage = new LoadToyImage();
            Toyonoff = true;

            // Physic 객체 초기화
            List<Image> toyImages = new List<Image> { fishingRodImage, yarnImage };
            physic = new Physic(catImage, toyImages, toyBoxButton);
            physic.Start();
        }

        private void toyBoxButton_Click(object sender, RoutedEventArgs e)
        {
            var fishingRod = _loadToyImage.GetFishingRod();
            var yarn = _loadToyImage.GetYarn();
            Toyonoff = !Toyonoff;

            if (Toyonoff)
            {
                // 내용물O 장난감 박스로 교체
                buttonImage.Source = new BitmapImage(new Uri(@"C:\Users\water\OneDrive\바탕 화면\퍼라운딩 조각1\퍼라운딩 조각1\장난감상자_내용물O.png"));

                // 장난감 이미지 숨기기
                SetToyImagesVisibility(Visibility.Collapsed);
            }
            else
            {
                // 내용물X 장난감 박스로 교체
                buttonImage.Source = new BitmapImage(new Uri(@"C:\Users\water\OneDrive\바탕 화면\퍼라운딩 조각1\퍼라운딩 조각1\장난감상자.png"));

                // 장난감 이미지 나타내기.. 근데 이제 이걸 장난감 나타날 때마다 늘 같은 위치에서 나타나게 해야 되나 고민중
                SetToyImagesVisibility(Visibility.Visible);
            }

            if (fishingRod != null) // null 체크
            {
                fishingRod.LoadPNG_FR();
                fishingRodImage.Source = fishingRod.Image;
            }
            else
            {
                MessageBox.Show("FishingRod를 가져오는 데 실패했습니다.");
            }

            if (yarn != null) // null 체크
            {
                yarn.LoadPNG_Y();
                yarnImage.Source = yarn.Image;
            }
            else
            {
                MessageBox.Show("Yarn을 가져오는 데 실패했습니다.");
            }
        }
        private void SetToyImagesVisibility(Visibility visibility)
        {
            foreach (var toyImage in physic.toyImages)
            {
                toyImage.Visibility = visibility;
            }
        }

        private void DraggableImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Image draggedImage = sender as Image;
            if (draggedImage != null)
            {
                _isDragging = true;
                draggedImage.CaptureMouse();
            }
        }
        private void DraggableImage_MouseMove(object sender, MouseEventArgs e)
        {
            Image draggedImage = sender as Image;

            if (_isDragging && draggedImage != null)
            {
                Point mousePos = e.GetPosition(this); 
                Canvas.SetLeft(draggedImage, mousePos.X - draggedImage.ActualWidth / 2);
                Canvas.SetTop(draggedImage, mousePos.Y - draggedImage.ActualHeight / 2);
            }
        }
        private void DraggableImage_MouseUp(object sender, MouseButtonEventArgs e)
        {
            Image draggedImage = sender as Image;

            if (draggedImage != null && _isDragging)
            {
                _isDragging = false;
                draggedImage.ReleaseMouseCapture();
            }
        }
        private void DraggableImage_Drop(object sender, DragEventArgs e)
        {

        }
    }
}
